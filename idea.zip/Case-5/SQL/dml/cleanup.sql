DELETE FROM ReferenceKind;
DELETE FROM ReferenceType;
DELETE FROM Placement;
DELETE FROM Person;
DELETE FROM Storage;