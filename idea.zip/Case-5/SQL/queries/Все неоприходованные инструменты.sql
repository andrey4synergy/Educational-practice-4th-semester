-- Все неоприходованные инструменты
SELECT *
FROM Item 
WHERE storage_id IS NULL